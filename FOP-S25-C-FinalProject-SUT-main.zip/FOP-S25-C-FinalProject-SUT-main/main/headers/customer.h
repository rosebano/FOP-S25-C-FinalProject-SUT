#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "room.h"

void show_customer_menu(Hotel* hotel, const char* name, const char* phone);

#endif